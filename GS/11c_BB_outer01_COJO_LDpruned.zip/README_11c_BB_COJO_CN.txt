BB outer_01 COJO 11c：对指定 CHIP SNP 先做 LD 去冗余（探索性）
================================================================

原因：11b 报错 “there is a collinearity problem of the given list of SNPs”。
日志显示 chr1 的 73 个条件 CHIP SNP 都匹配成功，失败不是 GWAS 输入问题，
而是给定条件集合中的严重共线性。

注意：11c 不是“完全条件于 100 个最优 CHIP SNP”的分析！
11c 在 813 个 outer-train 样本内，分别将 chr1/12 的 73/27 个
条件 CHIP SNP 按两两 LD r²>0.2 去冗余。只条件于保留的 CHIP 子集；
因此不能声称它控制了整个最优 CHIP 集合，也不能直接将结果作为正式
nested-CV 的 QTN 筛选步骤。它仅用于检验 QTN 是否还有条件关联信号。
也应注意：两两 LD 剪枝不保证不存在多变量共线性；若再次报同一错误，
先检查 GCTA 日志，不能把失败解释为无条件关联。

安装：
1. 下载 11c_BB_outer01_COJO_LDpruned.zip 并上传旧服务器 GS-reviewer/。
2. 在 GS-reviewer 目录执行：

unzip -o 11c_BB_outer01_COJO_LDpruned.zip -d scripts/
bash -n scripts/11c_BB_outer01_COJO_LDpruned.slurm
sbatch scripts/11c_BB_outer01_COJO_LDpruned.slurm

该任务不会重跑 CHIP/填充 GWAS，不会修改此前 11a、11b 的主要产物。
使用已有的：
  10_outer_test/06_COJO_pilot/outer_01/BB/selected_120_train_qc.{bed,bim,fam}
  10_outer_test/06_COJO_pilot/outer_01/BB/BB_outer01_genomewide_with_matched_chip.ma
  10_outer_test/06_COJO_pilot/outer_01/BB/chr1/12_selected.snps
  10_outer_test/06_COJO_pilot/outer_01/BB/chr1/12_conditional_chip.snps

检查：
  tail -n 60 logs/11c_BB01_COJO_<JOBID>.out
  cat 10_outer_test/06_COJO_pilot/outer_01/BB/BB_outer01_20QTN_COJO_LDpruned_vs_marginal.tsv

11c 新增结果（与原 11b 相互隔离）：
  chr1_cond_chip_LDprune_r2_0.2.prune.in / .prune.out
  chr12_cond_chip_LDprune_r2_0.2.prune.in / .prune.out
  cojo_chr1_LDpruned.cma.cojo
  cojo_chr12_LDpruned.cma.cojo
  BB_outer01_20QTN_COJO_LDpruned_vs_marginal.tsv
