#!/usr/bin/env python3
"""Compare 20 original QTN GWAS associations with GCTA COJO conditional effects."""
from pathlib import Path
import argparse
import csv
import math


def table(path):
    with path.open(newline='') as f:
        yield from csv.DictReader(f, delimiter='\t')


def read_whitespace_table(path):
    with path.open() as f:
        hd = f.readline().split()
        for line in f:
            v = line.split()
            if len(v) != len(hd):
                raise RuntimeError(f'Malformed row in {path}: {line.strip()}')
            yield dict(zip(hd, v))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--work', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    out = args.out
    qtnfile = args.work / '10_outer_test/04_imputed_clumping_expanded_qtn/outer_01/BB/marker_sets/extra_20.snps'
    ordered = [ln.strip() for ln in qtnfile.read_text().splitlines() if ln.strip()]
    if len(ordered) != 20:
        raise RuntimeError('Expected exactly 20 QTN SNPs')
    r2file = out / 'BB_outer01_QTN_vs_CHIP_max_r2.tsv'
    r2 = {row['QTN']: row for row in table(r2file)}

    cojo = {}
    for c in ('1','12'):
        prefix = out / f'cojo_chr{c}_LDpruned'
        candidates = [Path(str(prefix)+'.cma.cojo'), Path(str(prefix)+'.cma')]
        files = [f for f in candidates if f.is_file() and f.stat().st_size > 0]
        if not files:
            raise RuntimeError(f'No GCTA COJO output found, expected one of {candidates}')
        output = files[0]
        for row in read_whitespace_table(output):
            if 'SNP' not in row or 'pC' not in row:
                raise RuntimeError(f'Unexpected GCTA conditional output header: {output}')
            snp = row['SNP']
            if snp in cojo:
                raise RuntimeError(f'Duplicate COJO result SNP: {snp}')
            cojo[snp] = row
        print(f'Loaded chr{c} conditional result: {output}')

    rows = []
    for snp in ordered:
        r = cojo.get(snp)
        r2row = r2.get(snp, {})
        p_raw = r.get('p', 'NA') if r else 'NA'
        p_cond = r.get('pC', 'NA') if r else 'NA'
        status = ('not_reported' if r is None else
                  'conditional_NA' if p_cond.lower() in ('na','nan','-nan','') else
                  'conditional_finite')
        fold_change = 'NA'
        try:
            p0, p1 = float(p_raw), float(p_cond)
            if p0 > 0 and p1 > 0 and math.isfinite(p0) and math.isfinite(p1):
                fold_change = f'{p1/p0:.5g}'
        except (ValueError, TypeError):
            pass
        rows.append({
            'QTN': snp,
            'Max_r2_with_selected_CHIP': r2row.get('Max_r2_with_selected_CHIP', 'NA'),
            'Top_linked_CHIP': r2row.get('Top_linked_CHIP', 'NA'),
            'marginal_P': p_raw,
            'conditional_P': p_cond,
            'conditional_beta': r.get('bC', 'NA') if r else 'NA',
            'conditional_SE': r.get('bC_se', 'NA') if r else 'NA',
            'conditional_P_over_marginal_P': fold_change,
            'status': status,
        })
    path = out / 'BB_outer01_20QTN_COJO_LDpruned_vs_marginal.tsv'
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter='\t')
        w.writeheader()
        w.writerows(rows)
    print(f'Created: {path}')
    for key in ('conditional_finite', 'conditional_NA', 'not_reported'):
        print(f'{key}: {sum(r["status"] == key for r in rows)}/20')
    if any(r['status'] == 'not_reported' for r in rows):
        print('WARNING: some QTN were not reported; review the corresponding GCTA logs and allele/frequency filtering.')
    print('DONE: report contains 20 rows; NA values are preserved, not interpreted as null effects.')


if __name__ == '__main__':
    main()
